#include "LCD_DISCO_F429ZI.h"
#include "mbed.h"

LCD_DISCO_F429ZI LCD;

int main() {
  LCD.SetFont(&Font24);
  LCD.SetTextColor(LCD_COLOR_DARKBLUE);

  int secs = 0;

  while (1) {
    LCD.Clear(LCD_COLOR_WHITE);
    uint8_t text[30];
    LCD.DisplayStringAt(0, 40, (uint8_t *)"Hello World", LEFT_MODE);
    sprintf((char *)text, "Secs: %d", secs);
    LCD.DisplayStringAt(0, 80, (uint8_t *)&text, LEFT_MODE);
    thread_sleep_for(1000);
    secs++;
  }
}
